/*
 * CCD.c
 *
 *  Created on: 2013-3-22
 *      Author: chenty
 */


#include "CCD.h"
#include "PE_Types.h"
#include "CCD_SI.h"
#include "CCD_CLK.h"

/* Global value for CCD */
uint16_t Pixels[CCD_Pixels_Width][CCD_Channels];
uint16_t Counter;

/* Get all pixels from all channels and save them into  */
void GetPixels(){
	/* Init Counters */
	Counter = 0;

	/* Make all SI and CLK be Low for init */
	CCD_SI_PutVal(00);
	CCD_CLK_PutVal(00);
	WAIT1_Waitus(CCD_Init_Time);

	/* Work! */
	CCD_SI_PutVal(11);
	WAIT1_Waitus(CCD_Setup_Time);
	CCD_CLK_PutVal(11);
	WAIT1_Waitus(CCD_Hold_Time);
	CCD_SI_PutVal(00);
	for (Counter = 0; Counter < CCD_Pixels_Width; Counter++){
		/* CLK High Period */
		CCD_CLK_PutVal(11);
		WAIT1_Waitus(CCD_TW);

		/* CLK Low Period */
		CCD_CLK_PutVal(00);
		WAIT1_Waitus(CCD_TW);
    	AD1_Measure(TRUE);  // measure all channel, wait for result
    	AD1_GetValue16(Pixels[Counter]);  // Get AD conversion result
	}
	/* CLK High Period */
	CCD_CLK_PutVal(11);
	WAIT1_Waitus(CCD_TW);

	/* CLK Low Period */
	CCD_CLK_PutVal(00);
	WAIT1_Waitus(CCD_TW);
	
}
