/*
 * CCD.h
 *
 *  Created on: 2013-3-22
 *      Author: chenty
 *
 *  ADC usage:
 *  	Channel0: PTB1	(VIDEO2)
 *  	Channel1: PTB2	(VIDEO3)
 *  	Channel2: PTB3	(AZ)
 *  	Channel3: PTD6	(AR2)
 *  	
 *  AR2 :
 *  	Front:		Sag_Temp2 = 87296651
 *  	Balanced:	Sag_Temp2 = 7497179
 *  	
 */

#ifndef CCD_H_
#define CCD_H_

/* Const for CCD */
#define CCD_Channels 7
#define CCD_Pixels_Width 128
#define CCD_Setup_Time 2	//tsu us
#define CCD_Hold_Time 1	//th(SI) us
#define CCD_Init_Time 1 	//us
#define CCD_TW 1 //us
#define CCDL(i) Pixels[i][0]
#define CCDR(i) Pixels[i][1]

/* Const for Acc&Gyo */
//#define AAC_X(i)	Pixels[i][2]
//#define AAC_Y(i)	Pixels[i][3]
#define AAC_Z(i)	(Pixels[i][2] * 53919) //53919
//#define AR1(i)	(Pixels[i][5])
#define AR2(i)		((Pixels[i][3] - 29260))  //DONT MOD this //30625 //29260 //29200 
#define Fy			(Integral_AAC_E - 1501747972) //31400

void GetPixels();

#endif /* CCD_H_ */
