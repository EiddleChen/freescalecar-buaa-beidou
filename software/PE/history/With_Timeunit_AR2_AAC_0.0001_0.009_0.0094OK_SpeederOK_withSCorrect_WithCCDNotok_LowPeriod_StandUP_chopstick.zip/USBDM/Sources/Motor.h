/*
 * Motor.h
 *
 *  Created on: Apr 22, 2013
 *      Author: chenty
 *      
 *  Left:	PTE30 + PTE31    
 *  Right:	PTA4 + PTA5
 *  
 */

#ifndef MOTOR_H_
#define MOTOR_H_

void Set_Motors(int32_t Left,int32_t  Right);
void Set_Motors_Mono(int32_t Left,int32_t  Right);

#endif /* MOTOR_H_ */
