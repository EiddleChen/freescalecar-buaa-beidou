/** ###################################################################
**     Filename    : Events.c
**     Project     : ProcessorExpert
**     Processor   : MKL25Z128VLK4
**     Component   : Events
**     Version     : Driver 01.00
**     Compiler    : GNU C Compiler
**     Date/Time   : 2013-03-28, 17:52, # CodeGen: 0
**     Abstract    :
**         This is user's event module.
**         Put your event handler code here.
/**     Settings    :
**     Contents    :
**         Cpu_OnNMIINT - void Cpu_OnNMIINT(void);
**
** ###################################################################*/
/* MODULE Events */

#include "Cpu.h"
#include "Events.h"

/* User includes (#include below this line is not maintained by Processor Expert) */
#include "stdio.h"
#include "MMA8451.h"
#include "CCD.h"
#include "Motor.h"

extern volatile bool DataTransmittedFlg;
extern volatile bool DataReceivedFlg;
extern void Timer_Interrupt_CB(void);


/* Global value for speed */
uint32_t Speed1_Counter = 0;
uint32_t Speed1_Edges;
uint32_t Speed2_Counter = 0;
uint32_t Speed2_Edges;


/* Global value for MMA8451 */
extern MMA845X mma845x;

/* Global value for CCD */
extern uint16_t Pixels[CCD_Pixels_Width][CCD_Channels];

/* Global value for Self balanced */
int32_t AAC_E[CCD_Pixels_Width],AAC_E2[CCD_Pixels_Width];
int32_t Integral_AAC_E = 0,Integral_AAC_E2 = 0;
int32_t Motor_Speed;
int32_t Sag_Temp1 = 0;
int32_t Sag_Temp2 = 0;
int32_t Sag_Temp3 = 0;
int32_t Motor_Speed_PWM,Motor_Speed_PWM2;
int		Motor_Controler = 0;
#define k 0.001//0.001
#define k1 0.4
#define k2 100000
#define k3 0.0001

/*
** ===================================================================
**     Event       :  TU2_OnCounterRestart (module Events)
**
**     Component   :  TU2 [TimerUnit_LDD]
**     Description :
**         Called if counter overflow/underflow or counter is
**         reinitialized by modulo or compare register matching.
**         OnCounterRestart event and Timer unit must be enabled. See
**         <SetEventMask> and <GetEventMask> methods. This event is
**         available only if a <Interrupt> is enabled.
**     Parameters  :
**         NAME            - DESCRIPTION
**       * UserDataPtr     - Pointer to the user or
**                           RTOS specific data. The pointer passed as
**                           the parameter of Init method.
**     Returns     : Nothing
** ===================================================================
*/

/* Main Interrupt at 100Hz */

int i;
void TU2_OnCounterRestart(LDD_TUserData *UserDataPtr)
{
  /* Write your code here ... */
	//Timer_Interrupt_CB();
	
	 /* MMA8451 working */ 
	//MMA845X_Poll();

	/* CCD&Speed Working */

	/* Speed Polling */
	Speed1_Edges = Speed1_Counter;
	Speed2_Edges = Speed2_Counter;

	/* Speed Init */
	Speed1_Counter = 0;
	Speed2_Counter = 0;
	
	/* Init for CCD Measure */

	
	/* Make all SI and CLK be Low for init */
	CCD_SI_PutVal(00);
	CCD_CLK_PutVal(00);
	WAIT1_Waitus(CCD_Init_Time);

	/* CCD Init */
	CCD_SI_PutVal(11);
	WAIT1_Waitus(CCD_Setup_Time);
	CCD_CLK_PutVal(11);
	WAIT1_Waitus(CCD_Hold_Time);
	CCD_SI_PutVal(00);

	/* CCD Measure & Speed Counter */
	for (i = 0; i < CCD_Pixels_Width; i++){		
		/* CLK High Period */
		CCD_CLK_PutVal(11);
		WAIT1_Waitus(CCD_TW);

		/* CLK Low Period */
		CCD_CLK_PutVal(00);
		WAIT1_Waitus(CCD_TW);
	    AD1_Measure(TRUE);  // measure all channel, wait for result
	    AD1_GetValue16(Pixels[i]);  // Get AD conversion result
	}
	/* CLK High Period */
	CCD_CLK_PutVal(11);
	WAIT1_Waitus(CCD_TW);

	/* CLK Low Period */
	CCD_CLK_PutVal(00);
	WAIT1_Waitus(CCD_TW);
	Sag_Temp1 = 0;
	//Sag_Temp2 = 0;
	Sag_Temp3 = 0;
	/* Polling parameters of Components finish, write your code before */
	for (i = 0; i < CCD_Pixels_Width; i++){
//		AAC_E[i] = AR2(i) + k * (  AAC_Z(i) - Integral_AAC_E );
		Integral_AAC_E += AR2(i) + k * (  AAC_Z(i) - Integral_AAC_E );
		Sag_Temp1 += AR2(i);
//		Sag_Temp3 += AAC_Z(i);
	}
	//Integral_AAC_E += Sag_Temp1 / CCD_Pixels_Width;
//	Motor_Speed = Sag_Temp1 * k2 / 20 + k1 * Fy;	
	Integral_AAC_E2 = AAC_Z(0);
	
	Motor_Speed_PWM = (int32_t)(k3 * ( Sag_Temp1 * k2 / CCD_Pixels_Width + k1 * Fy) );
	Motor_Speed_PWM2 =(int32_t)(k3 * ( 0  * Sag_Temp1 * k2 / CCD_Pixels_Width + k1 * Fy) );
	if ( Motor_Controler++ >= 1 ) { Set_Motors(Motor_Speed_PWM,Motor_Speed_PWM); Motor_Controler = 0; } 
	
	//Printf for Debug
//	for (i = 0;i < CCD_Pixels_Width; i++) printf("%d,",AAC_Z(i) / 1000);
//	printf("\n");
//	for (i = 0;i < CCD_Pixels_Width; i++) printf("%d,",AR2(i));
//	printf("\n");	
//	printf("Integral= %d\n",Integral_AAC_E);
//	printf("Sag_Temp2 = %d\n",(int32_t)Sag_Temp2);b
}

/*
** ===================================================================
**     Event       :  I2C2_OnMasterBlockSent (module Events)
**
**     Component   :  I2C2 [I2C_LDD]
**     Description :
**         This event is called when I2C in master mode finishes the
**         transmission of the data successfully. This event is not
**         available for the SLAVE mode and if MasterSendBlock is
**         disabled. 
**     Parameters  :
**         NAME            - DESCRIPTION
**       * UserDataPtr     - Pointer to the user or
**                           RTOS specific data. This pointer is passed
**                           as the parameter of Init method.
**     Returns     : Nothing
** ===================================================================
*/
void I2C2_OnMasterBlockSent(LDD_TUserData *UserDataPtr)
{
  /* Write your code here ... */
	  DataTransmittedFlg = TRUE;
}

/*
** ===================================================================
**     Event       :  I2C2_OnMasterBlockReceived (module Events)
**
**     Component   :  I2C2 [I2C_LDD]
**     Description :
**         This event is called when I2C is in master mode and finishes
**         the reception of the data successfully. This event is not
**         available for the SLAVE mode and if MasterReceiveBlock is
**         disabled.
**     Parameters  :
**         NAME            - DESCRIPTION
**       * UserDataPtr     - Pointer to the user or
**                           RTOS specific data. This pointer is passed
**                           as the parameter of Init method.
**     Returns     : Nothing
** ===================================================================
*/
void I2C2_OnMasterBlockReceived(LDD_TUserData *UserDataPtr)
{
  /* Write your code here ... */
	  DataReceivedFlg = TRUE;
}

/*
** ===================================================================
**     Event       :  I2C2_OnError (module Events)
**
**     Component   :  I2C2 [I2C_LDD]
**     Description :
**         This event is called when an error (e.g. Arbitration lost)
**         occurs. The errors can be read with GetError method.
**     Parameters  :
**         NAME            - DESCRIPTION
**       * UserDataPtr     - Pointer to the user or
**                           RTOS specific data. This pointer is passed
**                           as the parameter of Init method.
**     Returns     : Nothing
** ===================================================================
*/
void I2C2_OnError(LDD_TUserData *UserDataPtr)
{
  /* Write your code here ... */
}

/*
** ===================================================================
**     Event       :  EInt1_OnInterrupt (module Events)
**
**     Component   :  EInt1 [ExtInt]
**     Description :
**         This event is called when an active signal edge/level has
**         occurred.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void EInt1_OnInterrupt(void)
{
  /* Write your code here ... */
	Speed1_Counter++;
}

/*
** ===================================================================
**     Event       :  EInt2_OnInterrupt (module Events)
**
**     Component   :  EInt2 [ExtInt]
**     Description :
**         This event is called when an active signal edge/level has
**         occurred.
**     Parameters  : None
**     Returns     : Nothing
** ===================================================================
*/
void EInt2_OnInterrupt(void)
{
  /* Write your code here ... */
	Speed2_Counter++;
}

/* END Events */

/*
** ###################################################################
**
**     This file was created by Processor Expert 10.0 [05.03]
**     for the Freescale Kinetis series of microcontrollers.
**
** ###################################################################
*/
