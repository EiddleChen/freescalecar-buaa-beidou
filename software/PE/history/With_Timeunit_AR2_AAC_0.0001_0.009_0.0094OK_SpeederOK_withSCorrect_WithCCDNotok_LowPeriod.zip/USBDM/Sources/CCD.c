/*
 * CCD.c
 *
 *  Created on: 2013-3-22
 *      Author: chenty
 */


#include "CCD.h"
#include "PE_Types.h"
#include "CCD_SI.h"
#include "CCD_CLK.h"

/* Global value for CCD */
uint16_t Pixels[CCD_Pixels_Width][2];
uint16_t Pixels_Counter = CCD_Pixels_Width;

/* Init for CCD Measure */
void CCD_Init(){
	/* Make all SI and CLK be Low for init */
	CCD_SI_PutVal(00);
	CCD_CLK_PutVal(00);
	WAIT1_Waitus(CCD_Init_Time);

	/* set SI to enable CCD Measure  */
	CCD_SI_PutVal(11);
	WAIT1_Waitus(CCD_Setup_Time);
	CCD_CLK_PutVal(11);
	WAIT1_Waitus(CCD_Hold_Time);
	CCD_SI_PutVal(00);
	
	/* Set Counter */
	Pixels_Counter = 0;
}

void CCD_measure_init(){		
	/* CLK High Period */
	CCD_CLK_PutVal(11);
//	WAIT1_Waitus(CCD_TW);

	/* CLK Low Period */
	CCD_CLK_PutVal(00);
//	WAIT1_Waitus(CCD_TW);
    if (Pixels_Counter < CCD_Pixels_Width) AD1_Measure(FALSE);  // measure all channel, wait for result
    else Pixels_Counter = 0 ;
//    AD1_GetValue16(Pixels[Counter]);  // Get AD conversion result
}
