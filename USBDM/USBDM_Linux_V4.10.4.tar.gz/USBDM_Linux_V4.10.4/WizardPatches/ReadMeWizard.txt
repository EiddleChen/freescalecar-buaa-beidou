The shortcuts in this folder will patch the New Project Wizards
for various version of Codewarrior.  These are run as part of the
USBDM installation process and it should not be necessary to run these separately.
